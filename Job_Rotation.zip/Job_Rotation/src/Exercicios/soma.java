package Exercicios;

public class soma {
    public static void ex1(){
        int soma = 0;
        int k = 0;
        for(int i=13; k < i; k++) {
            soma = soma + k;
        }
        System.out.println(soma);
    }
}
